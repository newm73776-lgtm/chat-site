# Media Directory

This directory stores uploaded videos for the GlassChat application.

Files are uploaded to Firebase Storage at: `media/video/`

Supported formats: MP4, WebM, MOV
