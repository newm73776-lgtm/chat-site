# Media Directory

This directory stores uploaded images for the GlassChat application.

Files are uploaded to Firebase Storage at: `media/pic/`

Supported formats: JPG, PNG, GIF, WebP
